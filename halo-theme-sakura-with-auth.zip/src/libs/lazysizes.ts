import lazySizes from 'lazysizes';

lazySizes.cfg.lazyClass = 'lazyload';