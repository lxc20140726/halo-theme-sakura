// 创建一个空的类，防止请求 category.min.js 时报错
export default class Category {}
